import React from 'react'

import DoctorAppointmentTable from '../../UI/DoctorAppointmentTable'

const OnlineClinic = () => {
  return (
      <>
        <DoctorAppointmentTable/>
      </>
  )
}

export default OnlineClinic