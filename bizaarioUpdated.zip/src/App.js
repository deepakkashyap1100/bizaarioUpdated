import './App.css'



import {
  createBrowserRouter,
  RouterProvider,
} from "react-router";

import 'react-multi-carousel/lib/styles.css';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

import ErrorComp from './AppLayout/ErrorComp';
import Layout from './AppLayout/Layout'
// import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import Home from './pages/Home';
import About from './pages/About';
import HospitalsPartners from './pages/HospitalsPartners';

import MedicalBoardPage from './pages/MedicalBoardPage';
import NewsArticles from './pages/NewsArticles';
import ContactUs from './pages/ContactUs';
import PrivacyPolicy from './pages/PrivacyPolicy';
import ArticleDetail from './components/news-article-page/ArticleDetail';
import CardList from './components/test/CardList';
import DetailCard from './components/test/DetailCard';
// import { articleData } from './components/news-article-page/ArticleData';
// import { cardsData } from './Data/LocalData';



export default function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: <Layout/>,
      errorElement: <ErrorComp/>,
      children: [
        {
          path: '/',
          element: <Home /> 
        },
        {
          path: '/about',
          element: <About/>
        },
        {
          path: '/partners',
          element: <HospitalsPartners />
        },
        {
          path: '/medical-board',
          element: <MedicalBoardPage />
        },
        {
          path: '/news-articles',
          element: <NewsArticles />
        },
        {
          path: '/contact',
          element: <ContactUs />
        },
        {
          path: '/privacy-policy',
          element: <PrivacyPolicy />
        },
        {
          path: '/news-articles/:id',
          element: <ArticleDetail />,
          // loader: cardsData
        },
        {
          path: '/test',
          element: <CardList />,
 
        },
    
        

      ]
    },

  ]);
  return (<RouterProvider 
    router={router} future={{v7_startTransition: true, }} 
  />

) 
}